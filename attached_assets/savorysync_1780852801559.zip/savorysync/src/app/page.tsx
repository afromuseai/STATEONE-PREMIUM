import Head from 'next/head'
export default function Home() {
  return (
    <>
      <Head>
        <title>SavorySync - AI-Driven Inventory Management for Restaurant Chains</title>
        <meta name="description" content="Reduce food costs and waste with SavorySync's AI-powered inventory management platform. Automate ordering, track waste reduction, and optimize inventory across multiple locations." />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700;900&family=Inter:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>
      <main dangerouslySetInnerHTML={{ __html: `<style>body{font-family:'Inter', sans-serif;background:linear-gradient(to bottom right, #0f0c29, #302b63, #24243e);color:#FFFFFF}</style>` }} />
    </>
  )
}